import requests
import json

# API-Konfiguration
LIMESURVEY_URL = "http://limesurvey.ddev.site/index.php/admin/remotecontrol"
USERNAME = "admin"
PASSWORD = "admin"

def get_session_key():
    """Holt einen Session-Key von der LimeSurvey API."""
    payload = {
        "method": "get_session_key",
        "params": [USERNAME, PASSWORD],
        "id": 1
    }
    headers = {"content-type": "application/json"}
    response = requests.post(LIMESURVEY_URL, data=json.dumps(payload), headers=headers)
    response.raise_for_status()
    return response.json()["result"]

def assign_participant_to_survey(session_key, survey_id, participant_id):
    """Fügt einen CPDB-Teilnehmer einer Umfrage hinzu."""
    payload = {
        "method": "assign_cpdb_participant_to_survey",
        "params": [session_key, survey_id, participant_id],
        "id": 1
    }
    headers = {"content-type": "application/json"}
    response = requests.post(LIMESURVEY_URL, data=json.dumps(payload), headers=headers)
    response.raise_for_status()
    return response.json()["result"]

if __name__ == "__main__":
    session_key = get_session_key()
    survey_id = "769569"
    # participant_id = "08bd93f6-0968-4260-8281-2a44f72a55fc" # ist schon drin!
    participant_id = "7dd1d6a8-6eb6-4c34-8276-0eaba3ee9961"

    try:
        result = assign_participant_to_survey(session_key, survey_id, participant_id)
        print(f"Result: {result}")
    finally:
        # Session-Key freigeben
        payload = {
            "method": "release_session_key",
            "params": [session_key],
            "id": 1
        }
        headers = {"content-type": "application/json"}
        requests.post(LIMESURVEY_URL, data=json.dumps(payload), headers=headers)
