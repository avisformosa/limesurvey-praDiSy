# detect_call_mode.R

detect_call_mode <- function() {

  # 1) Prüfe, ob wir in RStudio laufen
  in_rstudio <- FALSE
  # Variante A: rstudioapi::isAvailable()
  if (requireNamespace("rstudioapi", quietly = TRUE)) {
    in_rstudio <- rstudioapi::isAvailable()
  }
  # Variante B: Environment-Variable
  # in_rstudio <- in_rstudio || (Sys.getenv("RSTUDIO") == "1")

  # 2) Prüfe, ob wir interaktiv sind
  # (unterscheidet Konsole vs. Rscript)
  is_interactive <- interactive()

  # 3) Analysiere den Call-Stack
  calls <- sys.calls()
  if (length(calls) == 0) {
    # In manchen Umgebungen ist sys.calls() leer,
    # also vorsichtig sein
    calls <- list()
  }
  call_strings <- sapply(calls, function(x) paste(deparse(x), collapse = ""))

  # 4) Build the "switch" logic
  if (any(grepl("\\.rs\\.source|\\.rs\\.runScript", call_strings))) {
    # RStudio Run-Button
    msg <- "Aufgerufen durch RStudio-Run-Button (.rs.source/.rs.runScript)"
  } else if (in_rstudio && is_interactive) {
    # Interaktiv in RStudio, aber kein Run-Button
    msg <- "Interaktiv in RStudio (z.B. manuelles source() in RStudio-Konsole)"
  } else if (is_interactive) {
    # Interaktiv, aber offensichtlich kein RStudio
    msg <- "Interaktiv in einer Standard-R-Konsole (außerhalb RStudio)"
  } else {
    # Nicht interaktiv: Batch-Modus, Rscript, etc.
    # Optional: kleine Heuristik, ob es von einem Python-Skript kommt:
    cmd_args <- commandArgs()
    if (any(grepl("python", cmd_args, ignore.case = TRUE))) {
      msg <- "Batch-Modus via Python-Skript (R wahrscheinlich als Subprozess)."
    } else {
      msg <- "Batch-Modus (Rscript oder ähnliche nicht-interaktive Umgebung)."
    }
  }

  message(paste(">>> Modus-Erkennung:", msg))
  invisible(msg)
}

# --- Testen:
detect_call_mode()
