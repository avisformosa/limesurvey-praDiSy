# Lade notwendige Bibliotheken
library(DBI)
library(RPostgres)
library(data.table)

# Argumente vom Python-Skript
args <- commandArgs(trailingOnly = TRUE)
csv_path <- args[1]
diag_id <- args[2]
participant_id <- args[3]
date <- args[4]
time <- args[5]

# PostgreSQL-Verbindung
con <- dbConnect(
  RPostgres::Postgres(),
  dbname = "diagnostik",
  host = "localhost",
  port = 5432,
  user = "diagnostik_user",
  password = "#IntroiboAdAltareDeiAdDeumQuiLaetificatAnimaMea#"
)

# CSV-Datei lesen
data <- fread(csv_path)

# Beispielverarbeitung
print(paste("Processing CSV for Participant:", participant_id))
data[, participant_id := participant_id]
data[, diag_id := diag_id]

# In PostgreSQL schreiben
dbWriteTable(con, "survey_results", data, append = TRUE, row.names = FALSE)

# Verbindung schließen
dbDisconnect(con)
