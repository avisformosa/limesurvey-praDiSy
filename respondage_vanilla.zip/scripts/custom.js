/******************
    User custom JS
    ---------------

   Put JS-functions for your template here.
   If possible use a closure, or add them to the general Template Object "Template"
*/


$(document).on('ready pjax:scriptcomplete',function(){
    /**
     * Code included inside this will only run once the page Document Object Model (DOM) is ready for JavaScript code to execute
     * @see https://learn.jquery.com/using-jquery-core/document-ready/
     */

    // Replace classes
    $('.container-fluid').addClass('container');
    $('.container-fluid').removeClass('container-fluid'); 

    // Remove classes
    $('.survey-name.text-center').removeClass('text-center');
    $('.survey-description.text-center').removeClass('text-center');
    $('.survey-welcome.h5.text-primary').removeClass('text-primary');
    $('.survey-welcome.h5').removeClass('h5');
    $('.ls-privacy-head.h4.text-primary').removeClass('text-primary');
    $('.ls-privacy-head.h4').removeClass('h4');
    $('.space-col').removeClass('space-col'); 
    $('.group-title.text-center.h3').removeClass('h3');
    $('.group-title.text-center').removeClass('text-center');
    $('.text-info').removeClass('text-info');
    $('.group-description.row.well').removeClass('well');
    $('.group-description.row').removeClass('row');
    $('.text-muted').removeClass('text-muted');
    $('.limit-text-window').removeClass('limit-text-window');
    $('.save-message.card').removeClass('card');
    $('.save-message.bg-light').removeClass('bg-light');
    $('.save-survey-form.col-lg-8.offset-lg-2').removeClass('offset-lg-2');
    $('.save-survey-form.col-lg-8').removeClass('col-lg-8');
    $('.save-message .card-body').removeClass('card-body');
    $('.navbar-light.bg-light').removeClass('bg-light');
    $('.privacy.row').removeClass('row');
});
